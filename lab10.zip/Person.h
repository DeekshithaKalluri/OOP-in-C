#ifndef PERSON_H
#define PERSON_H

typedef struct _Person Person;

// declaration of function pointers type
typedef void (*fptrDisplayInfo)(Person*);
typedef void (*fptrDeleteInfo)(Person*);

struct _Person {
    char* firstName;
    char* lastName;

    // List of interfaces
    fptrDisplayInfo Display;
    fptrDeleteInfo Delete;
};

//Declare function prototypes here
Person* New_Person(char* pFirstName, char* pLastName);
void Person_Display(Person* pObj);
void Person_Delete(Person* pObj);

#endif

