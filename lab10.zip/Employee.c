#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Employee.h"

Employee* New_Employee(char* pFN, char* pLN, char* dep, char* comp, int salary) {
    Employee* pEmpObj = NULL;
    
    pEmpObj = (Employee*)malloc(sizeof(Employee));
    if(pEmpObj == NULL){
        printf("Out Of Memory\n"); 
        return NULL;
    }
    
    pEmpObj->baseObj = New_Person(pFN, pLN);
    if(pEmpObj->baseObj == NULL){
        printf("Out Of Memory\n"); 
        return NULL;
    }

    pEmpObj->company = (char*)malloc(sizeof(char)*(strlen(comp)+1));
    if(pEmpObj->company == NULL){
        printf("Out Of Memory\n"); 
        return NULL;
    }
    strcpy(pEmpObj->company, comp);
    
    pEmpObj->department = (char*)malloc(sizeof(char)*(strlen(dep)+1));
    if(pEmpObj->department == NULL){
        printf("Out Of Memory\n"); 
        return NULL;
    }
    strcpy(pEmpObj->department, dep);
    
    pEmpObj->salary = salary;
    
    pEmpObj->Display = Employee_Display;
    pEmpObj->Delete = Employee_Delete;
    
    return pEmpObj;
}

void Employee_Display(Employee* pEmpObj) {
    printf("\n*** Employee Info ***\n");
    pEmpObj->baseObj->Display(pEmpObj->baseObj);
    printf("Works in %s, in the %s department, making $%.2f\n", 
        pEmpObj->company, pEmpObj->department, pEmpObj->salary); 
}

void Employee_Delete(Employee* pEmpObj) {
    if (pEmpObj == NULL) return;
    pEmpObj->baseObj->Delete(pEmpObj->baseObj);
    free(pEmpObj->company);
    free(pEmpObj->department);
    free(pEmpObj);
}




