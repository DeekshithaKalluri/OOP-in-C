#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Person.h"


Person* New_Person(char* pFN, char* pLN) {
    Person* pObj = NULL;

    pObj = (Person*)malloc(sizeof(Person));
    if(pObj == NULL) {
        printf("Out Of Memory\n"); 
        return NULL;
    }
    
    pObj->firstName = (char*)malloc(sizeof(char)*(strlen(pFN)+1));
    if(pObj->firstName == NULL){
        printf("Out Of Memory\n"); 
        return NULL;
    }
    strcpy(pObj->firstName, pFN);
    
    pObj->lastName = (char*)malloc(sizeof(char)*(strlen(pLN)+1));
    if(pObj->lastName == NULL){
        printf("Out Of Memory\n"); 
        return NULL;
    }
    strcpy(pObj->lastName, pLN);
    
    pObj->Display = Person_Display;
    pObj->Delete = Person_Delete;

    return pObj;
}

void Person_Display(Person* pObj) {
    printf("Person Name: %s %s\n", pObj->firstName, pObj->lastName);
}

void Person_Delete(Person* pObj) {
    if (pObj == NULL) return;
    free(pObj->firstName);
    free(pObj->lastName);
    free(pObj);
}

