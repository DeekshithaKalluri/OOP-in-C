#include <stdio.h>
#include "Person.h"
#include "Employee.h"

int main(int argc, const char * argv[]) {
    Person* PersonObj = New_Person("Alice", "Sun");
    Employee* EmployeeObj = New_Employee("Bob", "Smith","HR", "TCS", 40000);

    //displaying person info
    PersonObj->Display(PersonObj);
    //displaying employee info
    EmployeeObj->Display(EmployeeObj);
    
    PersonObj->Delete(PersonObj);
    EmployeeObj->Delete(EmployeeObj);
    
    return 0;
}
