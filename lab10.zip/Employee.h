#ifndef INHERITANCE_EMPLOYEE_H
#define INHERITANCE_EMPLOYEE_H

#include "Person.h"

typedef struct _Employee Employee;
//define here a function pointer type for the Display emloyee function
typedef void (*fptrEmployeeDisplay)(Employee*);
typedef void (*fptrEmployeeDelete)(Employee*);

struct _Employee  {
    // Link to base class (struct)
    // Employee object fields here:
    // Company, Departmetn, Salary
    Person* baseObj;
    char* company;
    char* department;
    float salary;
    
    //If there is any employee specific functions; add it here.
    fptrEmployeeDisplay Display;
    fptrEmployeeDelete Delete;
};

Employee* New_Employee(char* pFN, char* pLN, char*  dep, char* company, int salary);
void Employee_Display(Employee* pEmpObj);
void Employee_Delete(Employee* pEmpObj);

#endif //INHERITANCE_EMPLOYEE_H

